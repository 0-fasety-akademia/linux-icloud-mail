import sys


def main():
    from .app import App
    return App().run(sys.argv)


if __name__ == "__main__":
    sys.exit(main())
