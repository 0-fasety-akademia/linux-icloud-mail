"""Linux iCloud Mail - a fast native iCloud Mail client for Ubuntu."""

VERSION = "0.1.3"
BUILD_DATE = "2026-11-04"
APP_ID = "io.github.jaro.LinuxIcloudMail"
APP_NAME = "Linux iCloud Mail"
BIN_NAME = "linux-icloud-mail"

IMAP_HOST = "imap.mail.me.com"
IMAP_PORT = 993
SMTP_HOST = "smtp.mail.me.com"
SMTP_PORT = 587
